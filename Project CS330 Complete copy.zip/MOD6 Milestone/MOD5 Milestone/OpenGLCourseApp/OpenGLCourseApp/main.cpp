#define STB_IMAGE_IMPLEMENTATION

#include <stdio.h>
#include <string.h>
#include <cmath>
#include <vector>

#include <GL\glew.h>
#include <GLFW\glfw3.h>

#include <glm\glm.hpp>
#include <glm\gtc\matrix_transform.hpp>
#include <glm\gtc\type_ptr.hpp>

#include "Window.h"
#include "Mesh.h"
#include "Shader.h"
#include "Camera.h"
#include "Texture.h"
#include "Light.h"

const float toRadians = 3.14159265f / 180.0f;

Window mainWindow;
std::vector<Mesh*> meshList;
std::vector<Shader> shaderList;
Camera camera;

Texture brickTexture;
Texture woodTexture;
Texture concreteTexture;

Light mainLight;

GLfloat deltaTime = 0.0f;
GLfloat lastTime = 0.0f;

// Vertex Shader
static const char* vShader = "Shaders/shader.vert";

// Fragment Shader
static const char* fShader = "Shaders/shader.frag";

void CreatePyramid()
{
	unsigned int indices[] = {
		0, 3, 1,
		1, 3, 2,
		2, 3, 0,
		0, 1, 2
	};

	GLfloat vertices[] = {
		//	x      y      z			u	  v
			-1.0f, -1.0f, 0.0f,		0.0f, 0.0f,
			0.0f, -1.0f, 1.0f,		0.5f, 0.0f,
			1.0f, -1.0f, 0.0f,		1.0f, 0.0f,
			0.0f, 1.0f, 0.0f,		0.5f, 1.0f
	};

	Mesh* obj1 = new Mesh();
	obj1->CreateMesh(vertices, indices, 20, 12);
	meshList.push_back(obj1);

	//Mesh* obj2 = new Mesh();
	//obj2->CreateMesh(vertices, indices, 20, 12);
	//meshList.push_back(obj2);
}
void CreateCube()
{
	// order of where the program should follow for drawing
	unsigned int indices[] = {
		0, 1, 2,
		2, 3, 0,
		3,4,2,
		4,3,5,
		5,6,7,
		5,4,6


	};

	GLfloat vertices[] = {
	-0.5,  0.5, -0.5,  0.0f, 0.0f,  //0 top left back
	-0.5, -0.5, -0.5,  1.0f, 0.0f, // 1 bottom left back
	 0.5, -0.5, -0.5,  0.0f, 1.0f, // 2 bottom right back
	 0.5,  0.5, -0.5,  1.0f, 0.0f, // 3  top right back end of first rect
	 0.0,-0.5f,0.5f,   0.0f, 1.0f, // 4 bottom middle front
	 0.0,0.7,0.5,	   1.0f, 0.0f, // 5 front middle top
	 -0.5,-0.5,-0.5,   0.0f, 0.0f,  // 6 bottom left back
	 -0.5,0.5,-0.5,     0.0f, 0.0f // 7 

	};

	Mesh* obj2 = new Mesh();
	obj2->CreateMesh(vertices, indices, sizeof(vertices), sizeof(indices));
	meshList.push_back(obj2);

	Mesh* obj3 = new Mesh();
	obj3->CreateMesh(vertices, indices, sizeof(vertices), sizeof(indices));
	meshList.push_back(obj3);

	Mesh* obj4 = new Mesh();
	obj4->CreateMesh(vertices, indices, sizeof(vertices), sizeof(indices));
	meshList.push_back(obj4);

}
void CreatePlane()
{  // order of where the program should follow for drawing
	unsigned int indices[] = {
		0,1,2,
		3,2,1
		

	};

	GLfloat vertices[] = {
		1.0f, 0.0f, -1.0f,  0.0f, 0.0f, //0 bottom left
		1.0f, 0.0f, 0.0f,   1.0f, 1.0f, // 1 middle front
		-1.0f, 0.0f, -1.0f, 0.0f, 1.0f,// 2 left bottom
		-1.0f, 0.0f, 0.0f,   0.0f, 1.0f// 3  right bottom

	};
	Mesh* obj5 = new Mesh();  // creating new object   constructor initializes everything to zero
	obj5->CreateMesh(vertices, indices, 16, 20);  // vertices amount, indices amount, then hard coding numbers 
	meshList.push_back(obj5);  // pushing it to the back of the meshList
}

void CreateThird()
{
	// order of where the program should follow for drawing
	unsigned int indices[] = {
		0, 1, 2,
		2, 3, 0,
		3,4,2,
		4,3,5,
		5,6,7,
		5,4,6


	};

	GLfloat vertices[] = {
	-0.5,  0.5, -0.5,  0.0f, 0.0f,  //0 top left back
	-0.5, -0.5, -0.5,  1.0f, 0.0f, // 1 bottom left back
	 0.5, -0.5, -0.5,  0.0f, 1.0f, // 2 bottom right back
	 0.5,  0.5, -0.5,  1.0f, 0.0f, // 3  top right back end of first rect
	 0.0,-0.5f,0.5f,   0.0f, 1.0f, // 4 bottom middle front
	 0.0,0.7,0.5,	   1.0f, 0.0f, // 5 front middle top
	 -0.5,-0.5,-0.5,   0.0f, 0.0f,  // 6 bottom left back
	 -0.5,0.5,-0.5,     0.0f, 0.0f // 7 

	};

	Mesh* obj6 = new Mesh();
	obj6->CreateMesh(vertices, indices, sizeof(vertices), sizeof(indices));
	meshList.push_back(obj6);

}
void CreateShaders()
{
	Shader* shader1 = new Shader();
	shader1->CreateFromFiles(vShader, fShader);
	shaderList.push_back(*shader1);
}

int main()
{
	mainWindow = Window(800, 600);
	mainWindow.Initialise();

	CreatePyramid();
	CreateCube();
	CreatePlane();
	CreateThird();
	CreateShaders();

	camera = Camera(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f), -90.0f, 0.0f, 5.0f, 0.5f);

	brickTexture = Texture("Textures/brick.png");
	brickTexture.LoadTexture();
	woodTexture = Texture("Textures/wood.png");
	woodTexture.LoadTexture();
	concreteTexture = Texture("Textures/concrete.png");
	concreteTexture.LoadTexture();

	mainLight = Light(1.0f, 1.0f, 1.0f, 0.5f);


	GLuint uniformProjection = 0, uniformModel = 0, uniformView = 0, uniformAmbientIntensity = 0, uniformAmbientColor = 0;
	glm::mat4 projection = glm::perspective(glm::radians(45.0f), (GLfloat)mainWindow.getBufferWidth() / mainWindow.getBufferHeight(), 0.1f, 100.0f);

	// Loop until window closed
	while (!mainWindow.getShouldClose())
	{
		GLfloat now = glfwGetTime(); 
		deltaTime = now - lastTime; 
		lastTime = now;

		// Get + Handle User Input
		glfwPollEvents();

		camera.keyControl(mainWindow.getsKeys(), deltaTime);
		camera.mouseControl(mainWindow.getXChange(), mainWindow.getYChange());

		// Clear the window
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		shaderList[0].UseShader();
		uniformModel = shaderList[0].GetModelLocation();
		uniformProjection = shaderList[0].GetProjectionLocation();
		uniformView = shaderList[0].GetViewLocation();
		uniformAmbientColor = shaderList[0].GetAmbientColorLocation();
		uniformAmbientIntensity = shaderList[0].GetAmbientIntensityLocation();


		mainLight.UseLight(uniformAmbientIntensity, uniformAmbientColor);

		glm::mat4 model(1.0f);


		//top pyramid
		model = glm::translate(model, glm::vec3(0.0f, 0.0f, -2.5f));
		model = glm::scale(model, glm::vec3(0.4f, 0.4f, 1.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));
		woodTexture.UseTexture();
		meshList[0]->RenderMesh();

		//flying pyramid
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(-2.0f, -0.70f, -4.0f));
		model = glm::scale(model, glm::vec3(1.0f, 2.7f, 1.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		brickTexture.UseTexture();
		meshList[1]->RenderMesh();

		//base of top pyramid
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(0.0f, -0.78f, -2.0f));
		model = glm::scale(model, glm::vec3(0.75f, 1.0f, 1.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		woodTexture.UseTexture();
		//add texture
		meshList[2]->RenderMesh();

		//second brick floater
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(-2.0f, -0.78f, -1.0f));
		model = glm::scale(model, glm::vec3(1.0f, 0.7f, 1.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		brickTexture.UseTexture();
		meshList[3]->RenderMesh();

		// bottom plane
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(-3.0f, -1.15f, 0.0f));
		model = glm::scale(model, glm::vec3(4.5f, 0.5f, 7.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		concreteTexture.UseTexture();
		//add texture
		meshList[4]->RenderMesh();

		//third object
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(0.0f, -0.78f, -5.0f));
		model = glm::scale(model, glm::vec3(1.0f, 0.7f, 1.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		woodTexture.UseTexture();
		meshList[5]->RenderMesh();

		glUseProgram(0);

		mainWindow.swapBuffers();
	}

	return 0;
}